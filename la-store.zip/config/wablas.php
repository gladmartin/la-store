<?php

return [
    'token' => env('WABLAS_TOKEN'),
];