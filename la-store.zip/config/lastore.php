<?php

return [
    'proxy_shared_hoting' => env('PROXY_SHARED_HOSTING'),
];