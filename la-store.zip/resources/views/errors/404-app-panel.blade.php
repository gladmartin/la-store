@extends('layouts.admin')

@section('title', '404 Not Found')

@section('content')


<!-- Content Row -->
{{-- <div class="row"> --}}

<div class="card">
    <div class="card-body text-center">
        <h3>404</h3>
        <p>Page Not Found</p>
    </div>
</div>


{{-- </div> --}}
@endsection
