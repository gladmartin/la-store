<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc>{{ url('/sitemap/menu') }}</loc>
        <loc>{{ url('/sitemap/produtcs') }}</loc>
        <loc>{{ url('/sitemap/posts') }}</loc>
        <loc>{{ url('/sitemap/categories') }}</loc>
    </sitemap>
</sitemapindex>