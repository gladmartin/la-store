<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
        <url>
            <loc>{{ route('site.home') }}</loc>
            <changefreq>weekly</changefreq>
            <priority>0.9</priority>
        </url>
        <url>
            <loc>{{ route('shop.index') }}</loc>
            <changefreq>weekly</changefreq>
            <priority>0.9</priority>
        </url>
        <url>
            <loc>{{ route('order.konfirmasi') }}</loc>
            <changefreq>weekly</changefreq>
            <priority>0.9</priority>
        </url>
        <url>
            <loc>{{ route('order.lacak') }}</loc>
            <changefreq>weekly</changefreq>
            <priority>0.9</priority>
        </url>
</urlset>