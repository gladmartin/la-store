<div class="col-12">
    <div class="lastore-alert lastore-alert-primary mt-4 shadow-sm">
        <div class="title">Opps..</div>
        <div class="rows">
            <div class="body col-8s">
                Tidak ada list produk yang ditampilkan.
            </div>
        </div>
        <div class="icon">
            <img src="{{ asset('/svg/undraw_package_arrived_63rf.svg') }}" alt="Konfirmasi bayar"
                width="100%">
        </div>
    </div>
</div>